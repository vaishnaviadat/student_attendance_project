/*document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll("canvas").forEach(function (canvas) {
        <canvas id="attendanceChart"></canvas>

        let present = parseInt(canvas.getAttribute("data-present"));
        let absent = parseInt(canvas.getAttribute("data-absent"));

        if (!isNaN(present) && !isNaN(absent)) {
            new Chart(canvas, {
                type: 'pie',
                data: {
                    labels: ['Present', 'Absent'],
                    datasets: [{
                        data: [present, absent],
                        backgroundColor: ['#4CAF50', '#FF5733']
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false
                }
            });
        }
    });
});*/

document.addEventListener("DOMContentLoaded", function () {

        var totalPresent = parseInt("{{ total_present|default:0 }}");
        var totalAbsent = parseInt("{{ total_absent|default:0 }}");

        console.log("Total Present:", totalPresent, "Total Absent:", totalAbsent);

        if (isNaN(totalPresent) || isNaN(totalAbsent)) {
            console.error("Error: Invalid data for Pie Chart.");
            return;
        }

        var ctx = document.getElementById('attendanceChart').getContext('2d');
        var attendanceChart = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: ['Present', 'Absent'],
                datasets: [{
                    data: [totalPresent, totalAbsent], 
                    backgroundColor: ['#4CAF50', '#FF5733'],
                    hoverOffset: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                    }
                }
            }
        });
    });


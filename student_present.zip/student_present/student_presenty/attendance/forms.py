from django import forms
from .models import Student

class StudentRegistrationForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = ['name', 'email', 'phone', 'class_name', 'roll_number', 'image']

class StudentAuthorizationForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = ['authorized']



from django import forms

class MonthSelectionForm(forms.Form):
    month = forms.DateField(widget=forms.SelectDateWidget(years=[2025,2026,2027]))  # You can define years

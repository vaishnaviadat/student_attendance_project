from django.urls import path
from .views import (
    home, register_student, view_students, student_detail,
    mark_attendance, view_attendance, present_students, absent_students, monthly_attendance
)

urlpatterns = [
    path('', home, name='home'),
    path('register/', register_student, name='register_student'),
    path('students/', view_students, name='view_students'),
    path('students/<int:pk>/', student_detail, name='student_detail'),
    path('mark/', mark_attendance, name='mark_attendance'),
    path('attendance/', view_attendance, name='view_attendance'),
    path('present_students/', present_students, name='present_students'),
    path('absent_students/', absent_students, name='absent_students'),
    path('monthly-attendance/', monthly_attendance, name='monthly_attendance'),



]



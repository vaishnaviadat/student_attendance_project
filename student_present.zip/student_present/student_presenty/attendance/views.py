import cv2
import face_recognition
import pickle
from datetime import datetime, date

from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse

from .forms import StudentRegistrationForm, StudentAuthorizationForm
from .models import Student, Attendance

def home(request):
    return render(request, 'attendance/home.html')

def register_student(request):
    if request.method == 'POST':
        form = StudentRegistrationForm(request.POST, request.FILES)
        if form.is_valid():
            student = form.save(commit=False)
            if 'image' in request.FILES:
                image_file = request.FILES['image']
                try:
                    image = face_recognition.load_image_file(image_file)
                    face_locations = face_recognition.face_locations(image)
                    if face_locations:
                        encoding = face_recognition.face_encodings(image, face_locations)[0]
                        student.face_encoding = pickle.dumps(encoding)
                except Exception as e:
                    print("Error processing image:", e)
            student.save()  # Now save the student (which will also save the image)
            return redirect('home')
    else:
        form = StudentRegistrationForm()
    return render(request, 'attendance/register_student.html', {'form': form})


def view_students(request):
    students = Student.objects.all()
    return render(request, 'attendance/view_students.html', {'students': students})

def student_detail(request, pk):
    student = get_object_or_404(Student, pk=pk)
    if request.method == 'POST':
        form = StudentAuthorizationForm(request.POST, instance=student)
        if form.is_valid():
            form.save()
            return redirect('view_students')
    else:
        form = StudentAuthorizationForm(instance=student)
    return render(request, 'attendance/student_detail.html', {'student': student, 'form': form})

import cv2
import face_recognition
import pickle
from datetime import datetime, date
from django.shortcuts import render
from django.http import HttpResponse
from .models import Student, Attendance

def mark_attendance(request):
    # Fetch authorized students
    students = Student.objects.filter(authorized=True)
    known_encodings = []
    student_ids = []

    for student in students:
        if student.face_encoding:
            known_encodings.append(pickle.loads(student.face_encoding))
            student_ids.append(student.id)

    cam = cv2.VideoCapture(0, cv2.CAP_DSHOW)  # Use CAP_DSHOW for Windows stability
    recognized_student = None
    face_recognized = False

    while True:
        ret, frame = cam.read()
        if not ret:
            break

        # Convert frame to RGB (face_recognition requires RGB format)
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        face_locations = face_recognition.face_locations(rgb_frame)
        face_encodings = face_recognition.face_encodings(rgb_frame, face_locations)

        if not face_encodings:
            cv2.putText(frame, "No Face Detected", (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
        else:
            face_recognized = False  # Reset recognition flag for each frame
            for encoding in face_encodings:
                # Compute face distances and find best match
                face_distances = face_recognition.face_distance(known_encodings, encoding)
                best_match_index = face_distances.argmin() if len(face_distances) > 0 else None
                
                if best_match_index is not None:
                    # Apply a threshold to avoid false positives
                    if face_distances[best_match_index] < 0.5:  # Adjust threshold if needed
                        recognized_student = Student.objects.get(id=student_ids[best_match_index])
                        face_recognized = True

                        today = date.today()
                        attendance_record = Attendance.objects.filter(student=recognized_student, date=today).first()

                        if attendance_record:
                            if not attendance_record.check_out:
                                attendance_record.check_out = datetime.now()
                                attendance_record.save()
                                cv2.putText(frame, f"{recognized_student.name} Checked Out", (50, 100),
                                            cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
                            else:
                                cv2.putText(frame, f"{recognized_student.name} Already Checked Out", (50, 100),
                                            cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 0), 2)
                        else:
                            Attendance.objects.create(student=recognized_student)
                            cv2.putText(frame, f"{recognized_student.name} Checked In", (50, 100),
                                        cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
                        break
                    else:
                        cv2.putText(frame, "Face Not Recognized", (50, 100), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
                else:
                    cv2.putText(frame, "Face Not Recognized", (50, 100), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)

        cv2.imshow("Mark Attendance", frame)
        if cv2.waitKey(1) & 0xFF == ord('q') or face_recognized:
            break

    cam.release()
    cv2.destroyAllWindows()

    if recognized_student:
        return HttpResponse(f"Attendance marked for {recognized_student.name}")
    else:
        return HttpResponse("Face Not Recognized. Please register the student.")
    

def view_attendance(request):
    records = Attendance.objects.all().order_by('-date', '-check_in')
    return render(request, 'attendance/view_attendance.html', {'records': records})
from datetime import date
from django.shortcuts import render
from .models import Student, Attendance

def present_students(request):
    today = date.today()
    # Get attendance records for today.
    attendance_records = Attendance.objects.filter(date=today)
    return render(request, 'attendance/present_students.html', {'records': attendance_records})

def absent_students(request):
    today = date.today()
    # Get a list of student IDs that have attendance recorded for today.
    present_student_ids = Attendance.objects.filter(date=today).values_list('student_id', flat=True)
    # Exclude those students from the complete list.
    absent_students = Student.objects.exclude(id__in=present_student_ids)
    return render(request, 'attendance/absent_students.html', {'students': absent_students})


from django.shortcuts import render
from django.db.models import Count
import json
from .models import Attendance, Student  # Ensure the correct models are used

def monthly_attendance(request):
    selected_month = request.GET.get('month', '1')  # Default to January
    selected_year = request.GET.get('year', '2025')  # Default to 2025

    # Convert to integer
    selected_month = int(selected_month)
    selected_year = int(selected_year)

    students = Student.objects.all()

    attendance_data = []
    total_present = 0
    total_absent = 0
    total_days = 30  # Assuming 30 days in a month

    for student in students:
        # Count Present Days (Days where student has check-in)
        present_days = Attendance.objects.filter(
            student=student,
            date__month=selected_month,
            date__year=selected_year,
            check_in__isnull=False  # Student checked in
        ).count()

        # Count Absent Days
        absent_days = total_days - present_days

        total_present += present_days
        total_absent += absent_days

        # Avoid division by zero
        attendance_percentage = (present_days / total_days * 100) if total_days > 0 else 0

        attendance_data.append({
            'student_id': student.id,
            'student_name': student.name,
            'roll_number': student.roll_number,
            'present_days': present_days,
            'absent_days': absent_days,
            'percentage': round(attendance_percentage, 2),
        })

    # Prepare data for the pie chart
    context = {
        'total_present': total_present,
        'total_absent': total_absent,
    }

    # Convert pie_data to JSON format
    pie_data_json = json.dumps(context)

    return render(request, 'attendance/monthly_attendance.html', {
        'attendance_data': attendance_data,
        'selected_month': selected_month,
        'selected_year': selected_year,
        'pie_data_json': pie_data_json,
    })



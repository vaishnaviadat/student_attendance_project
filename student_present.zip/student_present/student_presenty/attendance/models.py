import os
from django.db import models

def student_image_path(instance, filename):
    # Build a unique file path using the student’s roll number
    return os.path.join('student_images', f"{instance.roll_number}_{filename}")

class Student(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    phone = models.CharField(max_length=15)
    class_name = models.CharField(max_length=50)  # use class_name since 'class' is reserved
    roll_number = models.CharField(max_length=20, unique=True)
    image = models.ImageField(upload_to=student_image_path, blank=True, null=True)
    # We store the face encoding (using pickle to convert numpy array to bytes)
    face_encoding = models.BinaryField(blank=True, null=True)
    authorized = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.name} ({self.roll_number})"

class Attendance(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    date = models.DateField(auto_now_add=True)
    check_in = models.DateTimeField(auto_now_add=True)
    check_out = models.DateTimeField(blank=True, null=True)

    @property
    def duration(self):
        if self.check_out:
            return self.check_out - self.check_in
        return None

    def __str__(self):
        return f"{self.student.name} - {self.date}"
    
STATUS_CHOICES = (
    ('Present', 'Present'),
    ('Absent', 'Absent'),
)
"""class AttendanceRecord (models.Model):
    
        student = models.ForeignKey(Student, on_delete=models.CASCADE)
        date = models.DateField()
        status = models.CharField(max_length=10, choices=STATUS_CHOICES)

def __str__(self):
        return f"{self.student.name} - {self.date} - {self.status}" """


from django.db import models

class AttendanceRecord(models.Model):
    student = models.ForeignKey('Student', on_delete=models.CASCADE)
    date = models.DateField()
    status = models.CharField(max_length=10, choices=[('Present', 'Present'), ('Absent', 'Absent')])
    def __str__(self):
        return f"{self.student} - {self.date} - {self.status}"
class AttendanceSummary(models.Model):
    student = models.ForeignKey('Student', on_delete=models.CASCADE)
    month = models.IntegerField()
    year = models.IntegerField()
    present_days = models.IntegerField()
    absent_days = models.IntegerField()
    attendance_percentage = models.FloatField()

    class Meta:
        unique_together = ('student', 'month', 'year')  # Prevent duplicate records
